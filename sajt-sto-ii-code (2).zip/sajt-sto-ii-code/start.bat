@echo off
chcp 65001 > nul
echo Запуск локального сервера...
node server.js
pause
