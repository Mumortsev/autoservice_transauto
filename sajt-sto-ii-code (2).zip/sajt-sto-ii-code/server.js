const http = require('http');
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const { exec } = require('child_process');

const PUBLIC_DIR = __dirname;

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.webp': 'image/webp',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.otf': 'font/otf'
};

// -------------------------------------------------------------
// КЕШИРОВАНИЕ ЗАПРОСОВ К ИИ ДЛЯ МАКСИМАЛЬНОЙ ЭКОНОМИИ ТОКЕНОВ
// -------------------------------------------------------------
const CACHE_FILE = path.join(__dirname, 'cache_diagnostics.json');
const diagnosticCache = new Map();
const cacheStats = {
  total: 0,
  hits: 0,
  saved_tokens_est: 0
};

// Нормализация текста симптомов (регистр, пунктуация, повторные пробелы)
function normalizeSymptoms(str) {
  return String(str || '')
    .toLowerCase()
    .replace(/[.,!?;:()"'«»—–\-\[\]\/\\#\n\r\t]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

// Загрузка дискового кеша при старте сервера
function initDiagnosticCache() {
  try {
    if (fs.existsSync(CACHE_FILE)) {
      const raw = fs.readFileSync(CACHE_FILE, 'utf8');
      const parsed = JSON.parse(raw);
      if (typeof parsed === 'object' && parsed !== null) {
        Object.entries(parsed).forEach(([k, v]) => {
          diagnosticCache.set(k, v);
        });
        console.log(`[ИИ-Кеш] Загружено ${diagnosticCache.size} готовых диагностик из дискового кеша`);
      }
    }
  } catch (err) {
    console.warn('[ИИ-Кеш] Ошибка чтения кеша с диска:', err.message);
  }
}

let saveCacheTimer = null;
function persistCacheDebounced() {
  if (saveCacheTimer) clearTimeout(saveCacheTimer);
  saveCacheTimer = setTimeout(() => {
    try {
      const dump = {};
      for (const [k, v] of diagnosticCache.entries()) {
        dump[k] = v;
      }
      fs.writeFileSync(CACHE_FILE, JSON.stringify(dump, null, 2), 'utf8');
    } catch (err) {
      console.error('[ИИ-Кеш] Ошибка записи кеша на диск:', err.message);
    }
  }, 1000);
}

// Инициализируем кеш
initDiagnosticCache();

// Функция динамического чтения .env без перезапуска сервера
function getEnvConfig() {
  const envPath = path.join(__dirname, '.env');
  const config = {
    DEEPINFRA_API_KEY: process.env.DEEPINFRA_API_KEY || process.env.TOKENATOR_API_KEY || process.env.DEEPSEEK_API_KEY || '',
    DEEPINFRA_MODEL: process.env.DEEPINFRA_MODEL || process.env.TOKENATOR_MODEL || process.env.DEEPSEEK_MODEL || 'deepseek-ai/DeepSeek-V4.1-Flash-1017',
    DEEPINFRA_BASE_URL: process.env.DEEPINFRA_BASE_URL || process.env.TOKENATOR_BASE_URL || 'https://api.deepinfra.com/v1/openai',
    PORT: Number(process.env.PORT) || 80
  };

  if (fs.existsSync(envPath)) {
    try {
      const content = fs.readFileSync(envPath, 'utf8');
      content.split(/\r?\n/).forEach(line => {
        line = line.trim();
        if (line && !line.startsWith('#')) {
          const eqIdx = line.indexOf('=');
          if (eqIdx !== -1) {
            const key = line.substring(0, eqIdx).trim();
            let val = line.substring(eqIdx + 1).trim();
            if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
              val = val.slice(1, -1);
            }
            if (key === 'PORT' && process.env.PORT) {
              return;
            }
            config[key] = key === 'PORT' ? Number(val) : val;

            // Алиасы
            if (key === 'TOKENATOR_API_KEY' && !config.DEEPINFRA_API_KEY) config.DEEPINFRA_API_KEY = val;
            if (key === 'TOKENATOR_MODEL' && !config.DEEPINFRA_MODEL) config.DEEPINFRA_MODEL = val;
            if (key === 'TOKENATOR_BASE_URL' && !config.DEEPINFRA_BASE_URL) config.DEEPINFRA_BASE_URL = val;
          }
        }
      });
    } catch (e) {
      console.error('Ошибка чтения .env:', e);
    }
  }

  // Fallbacks
  if (!config.DEEPINFRA_API_KEY && config.TOKENATOR_API_KEY) config.DEEPINFRA_API_KEY = config.TOKENATOR_API_KEY;
  if (!config.DEEPINFRA_MODEL && config.TOKENATOR_MODEL) config.DEEPINFRA_MODEL = config.TOKENATOR_MODEL;
  if (!config.DEEPINFRA_BASE_URL && config.TOKENATOR_BASE_URL) config.DEEPINFRA_BASE_URL = config.TOKENATOR_BASE_URL;

  if (process.env.PORT) {
    config.PORT = Number(process.env.PORT);
  }

  return config;
}

// Запрос к DeepSeek через шлюз DeepInfra
async function queryDeepSeek(symptoms, config) {
  const apiKey = config.DEEPINFRA_API_KEY;
  const baseUrl = (config.DEEPINFRA_BASE_URL || 'https://api.deepinfra.com/v1/openai').replace(/\/+$/, '');
  const model = config.DEEPINFRA_MODEL || 'deepseek-ai/DeepSeek-V4.1-Flash-1017';

  const url = `${baseUrl}/chat/completions`;

  const systemPrompt = `Ты — мастер-консультант независимого мультибрендового автотехцентра.
Твоя задача — проводить предварительную, осторожную оценку неисправностей автомобилей по описанным симптомам понятным языком автовладельца, без технического жаргона и IT-терминов.

ВАЖНЕЙШИЕ ПРАВИЛА И СТИЛЬ ОБЩЕНИЯ (КРИТИЧЕСКИ ВАЖНО):
1. ОТВЕЧАЙ ОСТОРОЖНО И ПРИМЕРНО:
   Автомобиль не находится в боксе, поэтому любые выводы носят ориентировочный характер. Всегда используй приставку "от" к стоимости работ (например, "от 1 000 ₽").
2. ОБЯЗАТЕЛЬНО ПОДЧЁРКИВАЙ:
   Окончательная цена и точный перечень работ формируются исключительно после очного осмотра мастером-приёмщиком на подъёмнике в боксе.
3. СРОКИ И ВРЕМЯ НЕ ДАВАТЬ:
   Категорически запрещено называть сроки, минуты или часы выполнения работ! Без вскрытия узлов и осмотра крепежа срок не определяется.
4. ДАВАТЬ ОРИЕНТИРОВОЧНЫЕ ЦЕНЫ НА ЗАПЧАСТИ ("ОТ И ДО"):
   Для деталей, требующих замены, подбери реалистичный рыночный диапазон цен ("от ... до ... ₽") с пояснением, что цена зависит от бренда (качественный аналог или оригинал).
5. ЧЕЛОВЕЧЕСКИЙ ЯЗЫК БЕЗ IT-ЖАРГОНА:
   Никаких надписей вроде версий нейросетей, DeepSeek, "дефектовка", технических кодов или сложных системных обозначений. Пиши как вежливый мастер техцентра.

БАЗА СТОИМОСТИ РАБОТ АВТОТЕХЦЕНТРА (БАЗОВЫЕ СТАВКИ "ОТ", БРАТЬ ТОЛЬКО ИХ):
1. Кузовной цех и стапель:
- "Окраска детали в камере с подбором ЛКП": от 6500 руб
- "Пайка и восстановление геометрии бампера": от 3000 руб
- "Вытяжка геометрии на стапеле (1 контр. точка)": от 4500 руб
- "Локальная рихтовка элемента споттером": от 2500 руб
- "Замена крыла / навесного элемента кузова": от 1800 руб
- "Снятие и установка бампера": от 1500 руб
- "Абразивная полировка детали после окраса": от 1200 руб

2. Подвеска, рулевое и ходовая:
- "Диагностика ходовой части на подъёмнике": от 600 руб
- "Замена стоек стабилизатора (пара)": от 1000 руб
- "Замена втулок стабилизатора (пара)": от 800 руб
- "Замена шаровой опоры": от 800 руб
- "Замена сайлентблоков рычага": от 1200 руб
- "Замена переднего амортизатора / стойки": от 1800 руб
- "Замена ступичного подшипника": от 1600 руб
- "Замена рулевого наконечника": от 700 руб
- "Замена рулевой тяги": от 900 руб

3. Тормозная система:
- "Замена передних тормозных колодок": от 800 руб
- "Замена задних тормозных колодок": от 1000 руб
- "Замена тормозных дисков + колодок (ось)": от 1600 руб
- "Обслуживание и смазка суппорта": от 600 руб
- "Переборка суппорта с ремкомплектом": от 1500 руб
- "Замена тормозной жидкости с прокачкой": от 1200 руб

4. 3D Сход-развал:
- "3D сход-развал (одна ось)": от 1500 руб
- "3D сход-развал (две оси)": от 2000 руб

5. Двигатель, ТО и кондиционер:
- "Компьютерная диагностика ЭБУ сканером": от 800 руб
- "Замена моторного масла и фильтра": от 700 руб
- "Замена воздушного и салонного фильтров": от 500 руб
- "Замена свечей зажигания (комплект)": от 600 руб
- "Замена ремня навесного оборудования": от 900 руб
- "Заправка кондиционера фреоном R134a": от 1500 руб
- "Диагностика герметичности кондиционера": от 600 руб
- "Замена антифриза с промывкой системы": от 1000 руб

СТРОГИЕ ЗАПРЕТЫ:
1. Запретные темы: оружие, насилие, 18+, политика, религия. При их появлении вежливо верни к теме авто.
2. Не галлюцинировать: если симптомы туманные или вне базы — порекомендуй первичную диагностику на подъёмнике (от 600 руб) и очную консультацию с мастером-приёмщиком.

СТРОГИЙ ФОРМАТ ОТВЕТА — ТОЛЬКО JSON:
{
  "title": "ПРЕДВАРИТЕЛЬНАЯ ОЦЕНКА В ВЕРХНЕМ РЕГИСТРЕ (ДО 8 СЛОВ)",
  "accuracy": "Ориентировочно",
  "description": "Понятное человеческое объяснение возможных причин проблемы простыми словами. Обязательно добавь оговорку, что окончательная смета формируется только при очном осмотре в боксе.",
  "safety": "Рекомендация по безопасности: можно ли ехать или лучше вызвать эвакуатор.",
  "works": [
    {
      "id": "op_1",
      "name": "Название работы СТРОГО из прайса выше",
      "price_from": 1000,
      "price_text": "от 1 000 ₽"
    }
  ],
  "parts": [
    {
      "name": "Название необходимой детали",
      "price_range": "от 1 500 до 3 500 ₽",
      "note": "ориентировочно за качественный аналог или оригинал"
    }
  ],
  "disclaimer": "Окончательная стоимость работ и запчастей формируется мастером-приёмщиком только после осмотра автомобиля на подъёмнике."
}

В массив works включи ТОЛЬКО 2-4 наиболее подходящие работы из прайса выше. В массив parts включи ТОЛЬКО 1-3 ключевые детали (не пиши лишнего).
НЕ ПИШИ НИКАКОГО ТЕКСТА КРОМЕ JSON.`;

  const requestBody = {
    model: model,
    response_format: { type: 'json_object' },
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: `Симптомы автомобиля: "${symptoms}". Назови вероятные причины и подбери ориентировочные работы и запчасти из базы.` }
    ],
    temperature: 0.25,
    max_tokens: 1500
  };

  console.log(`[ИИ-Запрос] Отправка в DeepInfra: модель ${model}, URL: ${url}`);

  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`
    },
    body: JSON.stringify(requestBody)
  });

  if (!response.ok) {
    const errorText = await response.text();
    console.error(`[DeepInfra Error ${response.status}]:`, errorText);
    throw new Error(`DeepInfra API вернул статус ${response.status}: ${errorText.substring(0, 150)}`);
  }

  const result = await response.json();
  const rawContent = result?.choices?.[0]?.message?.content || '';

  // Извлечение и восстановление JSON при возможном срезе токенов
  let parsed = null;
  let cleanJson = rawContent.trim();
  const codeBlockMatch = cleanJson.match(/```(?:json)?\s*([\s\S]*?)\s*```/i);
  if (codeBlockMatch) {
    cleanJson = codeBlockMatch[1].trim();
  }
  const firstBrace = cleanJson.indexOf('{');
  if (firstBrace !== -1) {
    cleanJson = cleanJson.substring(firstBrace);
  }

  try {
    parsed = JSON.parse(cleanJson);
  } catch (err1) {
    // Автоматическое закрытие незакрытых кавычек и скобок
    try {
      let repaired = cleanJson;
      const quotes = (repaired.match(/"/g) || []).length;
      if (quotes % 2 !== 0) repaired += '"';
      const openBraces = (repaired.match(/\{/g) || []).length;
      const closeBraces = (repaired.match(/\}/g) || []).length;
      const openBrackets = (repaired.match(/\[/g) || []).length;
      const closeBrackets = (repaired.match(/\]/g) || []).length;
      for (let i = 0; i < openBrackets - closeBrackets; i++) repaired += ']';
      for (let i = 0; i < openBraces - closeBraces; i++) repaired += '}';
      parsed = JSON.parse(repaired);
    } catch (err2) {
      console.warn('Не удалось восстановить обрезанный JSON, переходим к очищенному описанию:', err2.message);
    }
  }

  if (parsed && typeof parsed === 'object') {
    // Нормализация полей для надежного отображения
    if (!parsed.works && Array.isArray(parsed.items)) {
      parsed.works = parsed.items.map(it => ({
        id: it.id || 'op',
        name: it.name,
        price_from: it.price || it.price_from || 0,
        price_text: `от ${it.price || it.price_from || 0} ₽`
      }));
    } else if (Array.isArray(parsed.works)) {
      parsed.items = parsed.works.map(w => ({
        id: w.id || 'op',
        name: w.name,
        price: w.price_from || 0
      }));
    }
    if (!Array.isArray(parsed.parts)) {
      parsed.parts = [];
    }
    if (!parsed.disclaimer) {
      parsed.disclaimer = 'Окончательная стоимость работ и запчастей формируется мастером-приёмщиком только после осмотра автомобиля на подъёмнике.';
    }

    return {
      success: true,
      source: 'deepinfra',
      model: model,
      data: parsed
    };
  } else {
    // Защита от утечки сырых JSON-структур в описание
    let humanDesc = rawContent;
    const matchDesc = rawContent.match(/"description"\s*:\s*"([^"\\]*(?:\\.[^"\\]*)*)"/);
    if (matchDesc) {
      humanDesc = matchDesc[1].replace(/\\n/g, ' ').replace(/\\"/g, '"');
    } else {
      humanDesc = humanDesc.replace(/\{[\s\S]*?\}/g, '').replace(/[{}\[\]"]/g, '').trim();
      if (humanDesc.length < 10) {
        humanDesc = 'По описанным признакам рекомендуется первичный инструментальный осмотр ходовой части на подъёмнике техцентра.';
      }
    }

    return {
      success: true,
      source: 'deepinfra_text',
      model: model,
      data: {
        title: 'ПРЕДВАРИТЕЛЬНАЯ ОЦЕНКА ПО СИМПТОМАМ',
        accuracy: 'Ориентировочно',
        description: humanDesc,
        safety: 'Рекомендуется осмотр на подъёмнике техцентра перед дальней поездкой.',
        works: [
          { id: 'ai_diag', name: 'Диагностика узлов на подъёмнике', price_from: 600, price_text: 'от 600 ₽' }
        ],
        parts: [],
        disclaimer: 'Окончательная стоимость работ и запчастей формируется мастером-приёмщиком только после осмотра автомобиля на подъёмнике.'
      }
    };
  }
}

function startServer(port) {
  const server = http.createServer(async (req, res) => {
    // CORS headers
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

    if (req.method === 'OPTIONS') {
      res.writeHead(204);
      res.end();
      return;
    }

    const config = getEnvConfig();

    // 1. API: Проверка статуса подключения DeepInfra / DeepSeek
    if (req.method === 'GET' && req.url === '/api/status') {
      const apiKey = config.DEEPINFRA_API_KEY || config.TOKENATOR_API_KEY || '';
      const hasKey = Boolean(
        apiKey &&
        apiKey !== 'YOUR_API_KEY_HERE' &&
        apiKey.length > 8
      );

      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
      res.end(JSON.stringify({
        configured: hasKey,
        provider: 'deepinfra',
        model: config.DEEPINFRA_MODEL,
        endpoint: config.DEEPINFRA_BASE_URL,
        cached_entries: diagnosticCache.size,
        cache_hits: cacheStats.hits,
        tokens_saved_est: cacheStats.saved_tokens_est,
        maskedKey: hasKey ? `${apiKey.substring(0, 7)}...${apiKey.slice(-4)}` : null
      }));
      return;
    }

    // 2. API: Дефектовка через DeepSeek / DeepInfra с кешированием
    if (req.method === 'POST' && req.url === '/api/diagnose') {
      let body = '';
      req.on('data', chunk => {
        body += chunk;
        if (body.length > 1e6) req.destroy(); // защита от переполнения
      });

      req.on('end', async () => {
        try {
          const payload = JSON.parse(body || '{}');
          const symptoms = (payload.symptoms || payload.query || '').trim();

          if (!symptoms || symptoms.length < 3) {
            res.writeHead(400, { 'Content-Type': 'application/json; charset=utf-8' });
            res.end(JSON.stringify({ error: 'Укажите описание симптомов неисправности (минимум 3 символа)' }));
            return;
          }

          const normKey = normalizeSymptoms(symptoms);
          cacheStats.total++;

          // 1. Проверка кеша (0 ms, 0 токенов!)
          if (diagnosticCache.has(normKey)) {
            cacheStats.hits++;
            cacheStats.saved_tokens_est += 650;
            const cached = diagnosticCache.get(normKey);
            cached.hits = (cached.hits || 0) + 1;
            persistCacheDebounced();

            console.log(`[ИИ-Кеш] HIT (#${cacheStats.hits}): 0 токенов потрачено для "${normKey.substring(0, 45)}..."`);
            res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
            res.end(JSON.stringify({
              success: true,
              source: 'cache',
              cached: true,
              model: config.DEEPINFRA_MODEL,
              data: cached.data
            }));
            return;
          }

          const apiKey = config.DEEPINFRA_API_KEY || config.TOKENATOR_API_KEY;
          const hasValidKey = Boolean(
            apiKey &&
            apiKey !== 'YOUR_API_KEY_HERE' &&
            apiKey.length > 8
          );

          if (!hasValidKey) {
            console.log('[Диагностика] Ключ DeepInfra ещё не настроен в .env, возвращаем статус ожидания ключа');
            res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
            res.end(JSON.stringify({
              success: false,
              source: 'need_key',
              message: 'API-ключ DeepInfra ещё не вставлен в файл .env. Вставьте ключ в .env для включения нейросети.',
              model: config.DEEPINFRA_MODEL
            }));
            return;
          }

          // 2. Вызов DeepSeek через DeepInfra (при отсутствии в кеше)
          console.log(`[ИИ-Кеш] MISS: запрос к DeepInfra для "${normKey.substring(0, 45)}..."`);
          const aiResult = await queryDeepSeek(symptoms, config);

          // 3. Сохранение успешного ответа в кеш
          if (aiResult && aiResult.success && aiResult.data) {
            diagnosticCache.set(normKey, {
              data: aiResult.data,
              cached_at: Date.now(),
              hits: 1
            });
            persistCacheDebounced();
            console.log(`[ИИ-Кеш] Сохранен новый ответ в кеш (Всего в кеше: ${diagnosticCache.size})`);
          }

          res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
          res.end(JSON.stringify(aiResult));

        } catch (apiError) {
          console.error('[Ошибка ИИ-Диагностики]:', apiError.message);
          res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
          res.end(JSON.stringify({
            success: false,
            source: 'api_error',
            error: apiError.message,
            model: config.DEEPINFRA_MODEL
          }));
        }
      });
      return;
    }

    // 3. Статические файлы
    let reqUrl;
    try {
      reqUrl = decodeURIComponent(req.url.split('?')[0]);
    } catch {
      reqUrl = req.url.split('?')[0];
    }

    let safePath = path.normalize(reqUrl).replace(/^(\.\.[\/\\])+/, '');
    if (safePath === '/' || safePath === '\\') {
      safePath = '/index.html';
    }

    const filePath = path.join(PUBLIC_DIR, safePath);

    function sendFile(targetPath) {
      const ext = path.extname(targetPath).toLowerCase();
      const contentType = MIME_TYPES[ext] || 'application/octet-stream';
      const isStaticAsset = ['.jpg', '.jpeg', '.png', '.webp', '.svg', '.ico', '.woff', '.woff2'].includes(ext);
      const isCompressible = ['.html', '.css', '.js', '.json', '.svg'].includes(ext);

      const headers = {
        'Content-Type': contentType,
        'Cache-Control': isStaticAsset ? 'public, max-age=2592000, immutable' : 'no-cache'
      };

      const acceptEncoding = req.headers['accept-encoding'] || '';
      if (isCompressible && acceptEncoding.includes('gzip')) {
        headers['Content-Encoding'] = 'gzip';
        res.writeHead(200, headers);
        const rawStream = fs.createReadStream(targetPath);
        const gzipStream = zlib.createGzip({ level: 6 });
        rawStream.pipe(gzipStream).pipe(res);
      } else {
        res.writeHead(200, headers);
        const stream = fs.createReadStream(targetPath);
        stream.pipe(res);
      }
    }

    fs.stat(filePath, (err, stats) => {
      if (!err && stats.isFile()) {
        sendFile(filePath);
        return;
      }

      // Нечувствительный к регистру поиск для Linux / Docker
      const dirName = path.dirname(filePath);
      const targetBase = path.basename(filePath).toLowerCase();

      fs.readdir(dirName, (readErr, files) => {
        if (!readErr && files) {
          const match = files.find(f => f.toLowerCase() === targetBase);
          if (match) {
            sendFile(path.join(dirName, match));
            return;
          }
        }
        res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('404: Файл не найден');
      });
    });
  });

  server.listen(port, () => {
    const url = `http://localhost:${port}`;
    console.log(`===============================================`);
    console.log(` Локальный сервер запущен: ${url}`);
    console.log(` ИИ-модуль DeepInfra (DeepSeek): готов`);
    console.log(` Файл настроек: ${path.join(__dirname, '.env')}`);
    console.log(`===============================================`);
  });

  server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      console.log(`Порт ${port} занят, пробуем ${port + 1}...`);
      startServer(port + 1);
    } else {
      console.error('Ошибка сервера:', err);
    }
  });
}

const initialConfig = getEnvConfig();
startServer(initialConfig.PORT);
