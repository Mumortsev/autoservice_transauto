@echo off
chcp 65001 > nul
echo ========================================================
echo   ДЕПЛОЙ В ОБЛАКО AMVERA (порт 80, Docker)
echo ========================================================
echo.
echo Отправка ветки master в репозиторий Amvera...
git push amvera master
echo.
if %ERRORLEVEL% EQU 0 (
    echo [УСПЕХ] Изменения успешно отправлены в Amvera!
    echo В панели Amvera началась автоматическая сборка Docker-контейнера.
) else (
    echo [ВНИМАНИЕ] Если запрашивается авторизация:
    echo Логин: genanana
    echo Пароль: ваш пароль от аккаунта Amvera (или личный токен доступа)
)
echo.
pause
